package com.fasterxml.jackson.databind.annotation;

public final class NoClass {}


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\fasterxml\jackson\databind\annotation\NoClass.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */