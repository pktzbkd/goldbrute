package com.fasterxml.jackson.databind.introspect;

public abstract interface WithMember<T>
{
  public abstract T withMember(AnnotatedMember paramAnnotatedMember);
}


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\fasterxml\jackson\databind\introspect\WithMember.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */