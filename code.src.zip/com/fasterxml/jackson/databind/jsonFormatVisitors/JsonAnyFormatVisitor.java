package com.fasterxml.jackson.databind.jsonFormatVisitors;

public abstract interface JsonAnyFormatVisitor
{
  public static class Base
    implements JsonAnyFormatVisitor
  {}
}


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\fasterxml\jackson\databind\jsonFormatVisitors\JsonAnyFormatVisitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */