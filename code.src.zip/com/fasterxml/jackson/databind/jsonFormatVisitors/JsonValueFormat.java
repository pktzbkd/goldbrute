package com.fasterxml.jackson.databind.jsonFormatVisitors;

public enum JsonValueFormat
{
  DATE_TIME,  DATE,  TIME,  UTC_MILLISEC,  REGEX,  COLOR,  STYLE,  PHONE,  URI,  EMAIL,  IP_ADDRESS,  IPV6,  HOST_NAME;
  
  private JsonValueFormat() {}
}


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\fasterxml\jackson\databind\jsonFormatVisitors\JsonValueFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */