package com.fasterxml.jackson.core.format;

public enum MatchStrength
{
  NO_MATCH,  INCONCLUSIVE,  WEAK_MATCH,  SOLID_MATCH,  FULL_MATCH;
  
  private MatchStrength() {}
}


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\fasterxml\jackson\core\format\MatchStrength.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */