package com.fasterxml.jackson.core;

public abstract interface FormatSchema
{
  public abstract String getSchemaType();
}


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\fasterxml\jackson\core\FormatSchema.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */