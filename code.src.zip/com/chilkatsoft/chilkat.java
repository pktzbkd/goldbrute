/*    */ package com.chilkatsoft;
/*    */ 
/*    */ 
/*    */ public class chilkat
/*    */ {
/*    */   public static String ck_NewStringUTF(SWIGTYPE_p_JNIEnv var0, String var1)
/*    */   {
/*  8 */     return chilkatJNI.ck_NewStringUTF(SWIGTYPE_p_JNIEnv.getCPtr(var0), var1);
/*    */   }
/*    */   
/*    */   public static byte[] SWIG_JavaArrayOutUchar(SWIGTYPE_p_JNIEnv var0, SWIGTYPE_p_unsigned_char var1, long var2) {
/* 12 */     return chilkatJNI.SWIG_JavaArrayOutUchar(SWIGTYPE_p_JNIEnv.getCPtr(var0), SWIGTYPE_p_unsigned_char.getCPtr(var1), var2);
/*    */   }
/*    */   
/*    */   public static void SWIG_JavaArrayInUchar(SWIGTYPE_p_JNIEnv var0, CkByteData var1, byte[] var2) {
/* 16 */     chilkatJNI.SWIG_JavaArrayInUchar(SWIGTYPE_p_JNIEnv.getCPtr(var0), CkByteData.getCPtr(var1), var1, var2);
/*    */   }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\chilkatsoft\chilkat.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */