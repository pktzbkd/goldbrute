/*    */ package com.chilkatsoft;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SWIGTYPE_p_JNIEnv
/*    */ {
/*    */   private transient long swigCPtr;
/*    */   
/*    */ 
/*    */   protected SWIGTYPE_p_JNIEnv(long var1, boolean var3)
/*    */   {
/* 12 */     this.swigCPtr = var1;
/*    */   }
/*    */   
/*    */   protected SWIGTYPE_p_JNIEnv() {
/* 16 */     this.swigCPtr = 0L;
/*    */   }
/*    */   
/*    */   protected static long getCPtr(SWIGTYPE_p_JNIEnv var0) {
/* 20 */     return var0 == null ? 0L : var0.swigCPtr;
/*    */   }
/*    */ }


/* Location:              C:\Users\Lab\Desktop\a.jar!\com\chilkatsoft\SWIGTYPE_p_JNIEnv.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */